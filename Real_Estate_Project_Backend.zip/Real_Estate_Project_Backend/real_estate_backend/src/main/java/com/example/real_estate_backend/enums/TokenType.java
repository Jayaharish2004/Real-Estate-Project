package com.example.real_estate_backend.enums;

public enum TokenType {
    BEARER
}